package JAVARuntime;

public class Initialize implements CPackCore
{
	public void start()
	{
		Console.log("Olá!");
	}
	
	public void repeat()
	{
		
	}
}