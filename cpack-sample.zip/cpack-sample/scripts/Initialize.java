package JAVARuntime;

public class Initialize extends Component
{
    @Override
    public void start()
    {
        Console.log("Hello!");
    }
    
    @Override
    public void repeat()
    {
        // ...
    }
}